CREATE VIEW "_classification_splitted" AS SELECT _classification_complete_new.id_sci_name,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Phylum]'::character varying(50))::text, 1), ('[Kingdom]: '::character varying(50))::text, 2) AS kingdom,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Class]'::character varying(50))::text, 1), ('[Phylum]: '::character varying(50))::text, 2) AS phylum,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Order]'::character varying(50))::text, 1), ('[Class]: '::character varying(50))::text, 2) AS class_,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Family]'::character varying(50))::text, 1), ('[Order]: '::character varying(50))::text, 2) AS order_,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Genus]'::character varying(50))::text, 1), ('[Family]: '::character varying(50))::text, 2) AS family_,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Species]'::character varying(50))::text, 1), ('[Genus]: '::character varying(50))::text, 2) AS genus,
    split_part(split_part(_classification_complete_new.classif_tree, ('[Species]: '::character varying(50))::text, 2), (' '::character varying(50))::text, 2) AS specificepithet,
    split_part(_classification_complete_new.classif_tree, ('. '::character varying(50))::text, 2) AS infraspecificepithet,
    _classification_complete_new.vernacularnames,
    _classification_complete_new.taxon_rank
   FROM _classification_complete_new
  WHERE (((_classification_complete_new.taxon_rank)::text <> ('Subspecies'::character varying(50))::text) AND ((_classification_complete_new.taxon_rank)::text <> ('Variety'::character varying(50))::text))
UNION
 SELECT _classification_complete_new.id_sci_name,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Phylum]'::character varying(50))::text, 1), ('[Kingdom]: '::character varying(50))::text, 2) AS kingdom,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Class]'::character varying(50))::text, 1), ('[Phylum]: '::character varying(50))::text, 2) AS phylum,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Order]'::character varying(50))::text, 1), ('[Class]: '::character varying(50))::text, 2) AS class_,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Family]'::character varying(50))::text, 1), ('[Order]: '::character varying(50))::text, 2) AS order_,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Genus]'::character varying(50))::text, 1), ('[Family]: '::character varying(50))::text, 2) AS family_,
    split_part(split_part(_classification_complete_new.classif_tree, (' [Species]'::character varying(50))::text, 1), ('[Genus]: '::character varying(50))::text, 2) AS genus,
    split_part(split_part(split_part(_classification_complete_new.classif_tree, ('[Species]: '::character varying(50))::text, 2), (' '::character varying(50))::text, 2), (' '::character varying(50))::text, 1) AS specificepithet,
    split_part(_classification_complete_new.classif_tree, ('. '::character varying(50))::text, 2) AS infraspecificepithet,
    _classification_complete_new.vernacularnames,
    _classification_complete_new.taxon_rank
   FROM _classification_complete_new
  WHERE (((_classification_complete_new.taxon_rank)::text = ('Subspecies'::character varying(50))::text) OR ((_classification_complete_new.taxon_rank)::text = ('Variety'::character varying(50))::text))
  ORDER BY 1;
