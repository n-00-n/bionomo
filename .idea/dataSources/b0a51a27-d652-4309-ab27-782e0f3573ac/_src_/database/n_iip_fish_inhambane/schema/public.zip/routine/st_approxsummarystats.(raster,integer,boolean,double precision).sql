create function st_approxsummarystats(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, sample_percent double precision DEFAULT 0.1) returns summarystats
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_summarystats($1, $2, $3, $4)
$$;
