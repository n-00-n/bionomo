create function st_assvg(text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_AsSVG($1::public.geometry,0,15);
$$;
