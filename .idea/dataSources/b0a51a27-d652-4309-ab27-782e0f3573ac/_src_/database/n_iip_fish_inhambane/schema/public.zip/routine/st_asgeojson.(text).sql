create function st_asgeojson(text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_AsGeoJson(1, $1::public.geometry,15,0);
$$;
