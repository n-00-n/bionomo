create function st_multipolygonfromtext(text) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_MPolyFromText($1)
$$;
