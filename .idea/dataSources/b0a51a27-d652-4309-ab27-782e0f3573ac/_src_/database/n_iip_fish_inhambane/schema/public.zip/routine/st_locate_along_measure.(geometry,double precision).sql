create function st_locate_along_measure(geometry, double precision) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_locate_between_measures($1, $2, $2)
$$;
