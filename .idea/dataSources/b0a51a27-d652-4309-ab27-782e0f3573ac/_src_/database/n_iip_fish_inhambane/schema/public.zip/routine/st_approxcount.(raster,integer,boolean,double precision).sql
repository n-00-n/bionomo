create function st_approxcount(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, sample_percent double precision DEFAULT 0.1) returns bigint
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_count($1, $2, $3, $4)
$$;
