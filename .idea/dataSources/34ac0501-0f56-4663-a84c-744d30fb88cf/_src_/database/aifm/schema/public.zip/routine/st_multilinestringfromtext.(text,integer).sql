create function st_multilinestringfromtext(text, integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_MLineFromText($1, $2)
$$;
