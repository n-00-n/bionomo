create function postgis_scripts_build_date() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2018-06-03 16:53:55'::text AS version
$$;
