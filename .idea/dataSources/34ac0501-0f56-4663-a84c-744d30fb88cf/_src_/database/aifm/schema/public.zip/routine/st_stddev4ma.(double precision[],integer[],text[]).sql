create function st_stddev4ma(value double precision[], pos integer[], VARIADIC userargs text[] DEFAULT NULL::text[]) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT stddev(unnest) FROM unnest($1)
$$;
