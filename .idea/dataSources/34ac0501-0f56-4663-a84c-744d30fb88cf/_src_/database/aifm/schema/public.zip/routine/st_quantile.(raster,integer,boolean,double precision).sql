create function st_quantile(rast raster, nband integer, exclude_nodata_value boolean, quantile double precision) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ( public._ST_quantile($1, $2, $3, 1, ARRAY[$4]::double precision[])).value
$$;
