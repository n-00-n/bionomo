CREATE VIEW info_bionomo_new AS SELECT units.id_unit AS id,
    sources.source_citation AS references_,
    z_lookup_recordbasis.recordbasis AS basisofrecord,
    units.catalogue_number AS catalognumber,
    units.unit_note AS occurrenceremarks,
    collectors.completename AS recordedby,
    z_lookup_gatheringmethod.gathering_method AS samplingprotocol,
    unit_counts.phase_or_stage AS reproductivecondition,
    units.lastdate AS eventdate,
    date_part('doy'::text, units.lastdate) AS enddayofyear,
    units.firstdate,
    date_part('doy'::text, units.firstdate) AS startdayofyear,
    date_part('year'::text, units.lastdate) AS year,
    date_part('month'::text, units.lastdate) AS month,
    date_part('day'::text, units.lastdate) AS day,
    gathering_sites.habitats AS habitat,
    'Africa'::text AS continent,
    'Mozambique'::text AS country,
    'MZ'::text AS countrycode,
    gathering_sites.province AS stateprovince,
    gathering_sites.district AS county,
    gathering_sites.locality,
    gathering_sites.max_elev AS maximumelevationinmeters,
    gathering_sites.min_elev AS minimumelevationinmeters,
    z_lookup_pointposition.pointposition_method AS locationaccordingto,
    site_position.wgs84_lat AS decimallatitude,
    site_position.wgs84_lng AS decimallongitude,
    'WGS84'::text AS geodeticdatum,
    site_position.uncertainty AS coordinateuncertaintyinmeters,
    identifiers.completename AS identifiedby,
    unit_identifications.ident_year AS dateidentified,
    z_lookup_identificationqualifier.ident_qualif AS identificationqualifier,
    units.typestatus,
    z_lookup_taxoncatalogue.sci_name AS scientificname,
    unit_identifications.id_sci_name
   FROM ((((((((((((((units
     JOIN gathering_sites ON ((gathering_sites.id_site = units.id_site)))
     JOIN site_position ON ((site_position.id_site = gathering_sites.id_site)))
     JOIN unit_identifications ON ((unit_identifications.id_unit = units.id_unit)))
     JOIN z_lookup_taxoncatalogue ON ((z_lookup_taxoncatalogue.id_sci_name = unit_identifications.id_sci_name)))
     LEFT JOIN sources ON ((sources.id_sc = units.id_source)))
     LEFT JOIN unit_counts ON ((unit_counts.id_unit = units.id_unit)))
     LEFT JOIN ident_agents ON ((ident_agents.id_idf = unit_identifications.id_idf)))
     LEFT JOIN gathering_agent ON ((gathering_agent.id_unit = units.id_unit)))
     LEFT JOIN z_lookup_agents identifiers ON ((identifiers.id_agent = ident_agents.id_agent)))
     LEFT JOIN z_lookup_agents collectors ON ((collectors.id_agent = gathering_agent.id_agent)))
     LEFT JOIN z_lookup_recordbasis ON ((z_lookup_recordbasis.id_rb = units.id_recordbasis)))
     LEFT JOIN z_lookup_identificationqualifier ON ((z_lookup_identificationqualifier.id_idq = unit_identifications.id_ident_qualifier)))
     LEFT JOIN z_lookup_pointposition ON ((z_lookup_pointposition.id_pp = site_position.id_pointposition_method)))
     LEFT JOIN z_lookup_gatheringmethod ON ((z_lookup_gatheringmethod.id_gmt = units.id_gatheringmethod)));
