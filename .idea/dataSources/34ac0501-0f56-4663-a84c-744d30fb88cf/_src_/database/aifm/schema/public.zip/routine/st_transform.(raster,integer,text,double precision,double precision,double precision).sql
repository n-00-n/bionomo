create function st_transform(rast raster, srid integer, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125, scalex double precision DEFAULT 0, scaley double precision DEFAULT 0) returns raster
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_gdalwarp($1, $3, $4, $2, $5, $6)
$$;
