create function st_pixelascentroid(rast raster, x integer, y integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_Centroid(geom) FROM public._ST_pixelaspolygons($1, NULL, $2, $3)
$$;
