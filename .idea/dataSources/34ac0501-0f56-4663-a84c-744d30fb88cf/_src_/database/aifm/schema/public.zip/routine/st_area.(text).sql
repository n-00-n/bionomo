create function st_area(text) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_Area($1::public.geometry);
$$;
