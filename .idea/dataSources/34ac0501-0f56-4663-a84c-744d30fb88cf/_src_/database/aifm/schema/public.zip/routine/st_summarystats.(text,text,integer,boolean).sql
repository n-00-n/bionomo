create function st_summarystats(rastertable text, rastercolumn text, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true) returns summarystats
STABLE
LANGUAGE SQL
AS $$
SELECT public._ST_summarystats($1, $2, $3, $4, 1)
$$;
