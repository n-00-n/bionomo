CREATE VIEW info_bionomo AS
  SELECT units.id_unit AS id,
    units.lastdate AS date,
    units.catalogue_number AS catalogue,
    units.id_site AS unit_site,
    unit_identifications.id_sci_name AS id_name,
    z_lookup_taxoncatalogue.sci_name,
    unit_identifications.id_idf,
    ident_agents.id_agent,
    z_lookup_agents.completename,
    gathering_sites.id_site,
    gathering_sites.province,
    gathering_sites.district,
    site_position.wgs84_lng AS x,
    site_position.wgs84_lat AS y,
    site_position.uncertainty
   FROM ((((((units
     JOIN unit_identifications ON ((unit_identifications.id_unit = units.id_unit)))
     JOIN z_lookup_taxoncatalogue ON ((z_lookup_taxoncatalogue.id_sci_name = unit_identifications.id_sci_name)))
     LEFT JOIN ident_agents ON ((ident_agents.id_idf = unit_identifications.id_idf)))
     LEFT JOIN z_lookup_agents ON ((z_lookup_agents.id_agent = ident_agents.id_agent)))
     JOIN gathering_sites ON ((gathering_sites.id_site = units.id_site)))
     JOIN site_position ON ((site_position.id_site = gathering_sites.id_site)));

