CREATE VIEW "_classification_complete" AS
  WITH RECURSIVE gerarchia AS (
         SELECT z_lookup_taxoncatalogue.id_sci_name,
            z_lookup_taxoncatalogue.sci_name,
            z_lookup_taxoncatalogue.parent_taxon,
            z_lookup_taxoncatalogue.authorship,
            ((('['::text || (z_lookup_taxoncatalogue.taxon_rank)::text) || ']: '::text) || ((z_lookup_taxoncatalogue.sci_name)::character varying(1000))::text) AS classif_tree,
            z_lookup_taxoncatalogue.taxon_rank
           FROM z_lookup_taxoncatalogue
          WHERE (z_lookup_taxoncatalogue.parent_taxon IS NULL)
        UNION ALL
         SELECT si.id_sci_name,
            si.sci_name,
            si.parent_taxon,
            si.authorship,
            (((((sp.classif_tree || ' ['::text) || (si.taxon_rank)::text) || ']: '::text) || (si.sci_name)::text))::character varying(1000) AS classif_tree,
            si.taxon_rank
           FROM (z_lookup_taxoncatalogue si
             JOIN gerarchia sp ON ((si.parent_taxon = sp.id_sci_name)))
        )
 SELECT gerarchia.id_sci_name,
    gerarchia.classif_tree,
    gerarchia.taxon_rank,
    gerarchia.authorship
   FROM gerarchia
  ORDER BY gerarchia.classif_tree;

