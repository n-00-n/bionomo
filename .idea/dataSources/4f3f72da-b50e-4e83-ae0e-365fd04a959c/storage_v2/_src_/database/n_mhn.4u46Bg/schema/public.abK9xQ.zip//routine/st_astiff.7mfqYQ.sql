CREATE FUNCTION st_astiff(rast raster, nbands integer[], compression text, srid integer DEFAULT NULL::integer)
  RETURNS bytea
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT st_astiff(st_band($1, $2), $3, $4)
$$;

