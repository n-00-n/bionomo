CREATE FUNCTION dropgeometrycolumn(table_name character varying, column_name character varying)
  RETURNS text
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
	ret text;
BEGIN
	SELECT public.DropGeometryColumn('','',$1,$2) into ret;
	RETURN ret;
END;
$$;

