CREATE FUNCTION st_setbandnodatavalue(rast raster, nodatavalue double precision)
  RETURNS raster
LANGUAGE SQL
AS $$
SELECT public.ST_setbandnodatavalue($1, 1, $2, FALSE)
$$;

