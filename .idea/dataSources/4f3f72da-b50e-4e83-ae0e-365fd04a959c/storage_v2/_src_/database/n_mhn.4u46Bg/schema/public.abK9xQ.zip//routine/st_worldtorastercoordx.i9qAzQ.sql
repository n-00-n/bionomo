CREATE FUNCTION st_worldtorastercoordx(rast raster, xw double precision, yw double precision)
  RETURNS integer
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT columnx FROM public._ST_worldtorastercoord($1, $2, $3)
$$;

