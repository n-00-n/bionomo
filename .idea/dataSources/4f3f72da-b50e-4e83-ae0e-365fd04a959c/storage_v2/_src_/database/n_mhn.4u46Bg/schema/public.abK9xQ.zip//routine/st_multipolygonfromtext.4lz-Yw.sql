CREATE FUNCTION st_multipolygonfromtext(text)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_MPolyFromText($1)
$$;

