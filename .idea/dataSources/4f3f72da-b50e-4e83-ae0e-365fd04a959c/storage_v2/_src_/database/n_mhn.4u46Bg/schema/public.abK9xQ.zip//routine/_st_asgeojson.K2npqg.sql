CREATE FUNCTION "_st_asgeojson"(integer, geometry, integer, integer)
  RETURNS text
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_AsGeoJson($2::public.geometry, $3::int4, $4::int4);
$$;

