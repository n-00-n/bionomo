CREATE FUNCTION st_histogram(rast raster, nband integer, bins integer, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision)
  RETURNS SETOF record
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT min, max, count, percent FROM public._ST_histogram($1, $2, TRUE, 1, $3, $4, $5)
$$;

