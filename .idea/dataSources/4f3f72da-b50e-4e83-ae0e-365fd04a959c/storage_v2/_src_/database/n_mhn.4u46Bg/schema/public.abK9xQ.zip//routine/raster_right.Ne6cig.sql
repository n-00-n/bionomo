CREATE FUNCTION raster_right(raster, raster)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
select $1::geometry >> $2::geometry
$$;

