CREATE FUNCTION raster_overleft(raster, raster)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
select $1::public.geometry &< $2::public.geometry
$$;

