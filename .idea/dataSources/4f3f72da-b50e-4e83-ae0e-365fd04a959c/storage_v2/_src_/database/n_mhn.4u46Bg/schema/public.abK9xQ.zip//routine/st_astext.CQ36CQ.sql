CREATE FUNCTION st_astext(text)
  RETURNS text
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_AsText($1::public.geometry);
$$;

