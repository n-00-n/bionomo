CREATE FUNCTION st_3dintersects(geom1 geometry, geom2 geometry)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_3DIntersects($1, $2)
$$;

