CREATE FUNCTION overlaps_geog(geography, gidx)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT $2 OPERATOR(public.&&) $1;
$$;

