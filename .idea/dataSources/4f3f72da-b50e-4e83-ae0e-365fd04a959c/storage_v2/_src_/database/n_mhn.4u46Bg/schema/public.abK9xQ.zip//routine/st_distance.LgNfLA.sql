CREATE FUNCTION st_distance(text, text)
  RETURNS double precision
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_Distance($1::public.geometry, $2::public.geometry);
$$;

