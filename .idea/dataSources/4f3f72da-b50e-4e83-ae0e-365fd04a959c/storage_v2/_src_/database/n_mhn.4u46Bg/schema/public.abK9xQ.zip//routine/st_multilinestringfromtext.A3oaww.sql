CREATE FUNCTION st_multilinestringfromtext(text)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_MLineFromText($1)
$$;

