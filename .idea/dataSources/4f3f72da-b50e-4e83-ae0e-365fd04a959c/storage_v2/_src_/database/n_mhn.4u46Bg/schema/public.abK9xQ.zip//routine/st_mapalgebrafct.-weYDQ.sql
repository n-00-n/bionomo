CREATE FUNCTION st_mapalgebrafct(rast raster, pixeltype text, onerastuserfunc regprocedure)
  RETURNS raster
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_mapalgebrafct($1, 1, $2, $3, NULL)
$$;

