CREATE FUNCTION st_reclass(rast raster, reclassexpr text, pixeltype text)
  RETURNS raster
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT st_reclass($1, ROW(1, $2, $3, NULL))
$$;

