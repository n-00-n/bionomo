CREATE FUNCTION st_area(text)
  RETURNS double precision
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_Area($1::public.geometry);
$$;

