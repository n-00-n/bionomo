CREATE VIEW info_bionomo_class AS
  SELECT info_bionomo.id,
    info_bionomo.date,
    info_bionomo.catalogue,
    info_bionomo.unit_site,
    info_bionomo.id_name,
    info_bionomo.sci_name,
    _classification_complete.authorship,
    _classification_complete.classif_tree,
    info_bionomo.completename AS identifier_name,
    info_bionomo.id_site,
    info_bionomo.province,
    info_bionomo.district,
    info_bionomo.x,
    info_bionomo.y,
    info_bionomo.uncertainty
   FROM (info_bionomo
     JOIN _classification_complete ON ((_classification_complete.id_sci_name = info_bionomo.id_name)))
  ORDER BY info_bionomo.id;

