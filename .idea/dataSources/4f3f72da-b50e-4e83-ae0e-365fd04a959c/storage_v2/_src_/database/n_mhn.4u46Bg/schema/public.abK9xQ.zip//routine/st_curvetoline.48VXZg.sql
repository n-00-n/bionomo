CREATE FUNCTION st_curvetoline(geometry, integer)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT ST_CurveToLine($1, $2::float8, 0, 0)
$$;

