CREATE FUNCTION st_dwithin(text, text, double precision)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_DWithin($1::public.geometry, $2::public.geometry, $3);
$$;

