CREATE FUNCTION dropgeometrytable(schema_name character varying, table_name character varying)
  RETURNS text
STRICT
LANGUAGE SQL
AS $$
SELECT public.DropGeometryTable('',$1,$2)
$$;

