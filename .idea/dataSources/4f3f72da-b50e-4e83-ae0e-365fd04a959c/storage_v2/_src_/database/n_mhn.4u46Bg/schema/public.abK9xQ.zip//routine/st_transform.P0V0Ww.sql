CREATE FUNCTION st_transform(geom geometry, from_proj text, to_proj text)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.postgis_transform_geometry($1, $2, $3, 0)
$$;

