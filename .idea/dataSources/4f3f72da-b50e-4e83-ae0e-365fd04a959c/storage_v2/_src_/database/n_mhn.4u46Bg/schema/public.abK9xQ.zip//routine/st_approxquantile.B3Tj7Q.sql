CREATE FUNCTION st_approxquantile(rastertable text, rastercolumn text, quantiles double precision[], OUT quantile double precision, OUT value double precision)
  RETURNS SETOF record
STABLE
STRICT
LANGUAGE SQL
AS $$
SELECT public._ST_quantile($1, $2, 1, TRUE, 0.1, $3)
$$;

