create function st_within(geom1 geometry, geom2 geometry) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $2 OPERATOR(public.~) $1 AND public._ST_Contains($2,$1)
$$;
