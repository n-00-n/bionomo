create function st_length2d_spheroid(geometry, spheroid) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._postgis_deprecate('ST_Length2D_Spheroid', 'ST_Length2DSpheroid', '2.2.0');
    SELECT public.ST_Length2DSpheroid($1,$2);
$$;
