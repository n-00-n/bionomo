create function postgis_scripts_build_date() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2018-07-29 16:57:44'::text AS version
$$;
