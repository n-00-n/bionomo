create function "_postgis_scripts_pgsql_version"() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '100'::text AS version
$$;
